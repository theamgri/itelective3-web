const express = require('express')
const app = express();
//app.set('views', './views');
app.set('view engine', 'ejs');
app.get('/', async function (req, res) {
 

  //res.render('pages/index', data);
  res.render('index.ejs');
  res.render('other.ejs');
  
 app.use( express.static( "views" ) ); // not sure if tama

});
var weather = require('weather-js');
weather.find({search: 'Davao, PH', degreeType: 'C'}, function(err, result) {
  var data = result;
 
//wdata = {itemData: result}
 
  if(err) {
   console.log(err) 
   
  }
  else {
    
  console.log(JSON.stringify(result, null, 2)); 
  app.render('index.ejs', {itemData:wdata});
  console.log(itemData['name']);
 //result.get('pages/index', weather)
 
  }
  
});

//app.listen(8080);
console.log('Server is listening on port 8080');

app.listen(3000);