const express = require('express')
const app = express();
//app.set('views', './views');
app.set('view engine', 'ejs');
app.get('/', function (req, res) {
 

  //res.render('pages/index', data);
  res.render('index.ejs');
  res.render('other.ejs');
});
app.use( express.static( "views" ) ); // not sure if tama
var weather = require('weather-js');
 
// Options:
// search:     location name or zipcode
// degreeType: F or C

Weather.getCurrent("Davao City", function(current) {
  console.log(
    ["currently:",current.temperature(),"and",current.conditions()].join(" ")
  );
});
 
Weather.getForecast("Davao City", function(forecast) {
  console.log("forecast high: " + forecast.high());
  console.log("forecast low: " + forecast.low());
});

app.listen(8080);
console.log('Server is listening on port 8080');

app.listen(3000);