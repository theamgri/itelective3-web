const express = require('express')
const app = express();
//app.set('views', './views');
app.set('view engine', 'ejs');
app.get('/', function (req, res) {
 

  //res.render('pages/index', data);
  res.render('index.ejs');
  res.render('other.ejs');
  
 app.use( express.static( "views" ) ); // not sure if tama

});
var weather = require('weather-js');
weather.find({search: 'Davao, PH', degreeType: 'C'}, function(err, result) {
  var data = result;
 wd = { [
  {
    location: {
      name: "Davao, Philippines",
      lat: "7.051",
      long: "125.595",
      timezone: "8",
      alert: "",
      degreetype: "F",
      imagerelativeurl: "http://blob.weather.microsoft.com/static/weather4/en-us/"
    },
    current: {
      temperature: "84",
      skycode: "9",
      skytext: "Light Rain",
      date: "2022-09-27",
      observationtime: "19:42:07",
      observationpoint: "Davao, Philippines",
      feelslike: "92",
      humidity: "75",
      winddisplay: "5 mph South",
      day: "Tuesday",
      shortday: "Tue",
      windspeed: "5 mph",
      imageUrl: "http://blob.weather.microsoft.com/static/weather4/en-us/law/9.gif"
    },
    "forecast": [
      {
        "low": "79",
        "high": "92",
        "skycodeday": "28",
        "skytextday": "Mostly Cloudy",
        "date": "2022-09-27",
        "day": "Tuesday",
        "shortday": "Tue",
        "precip": "6"
      },
      {
        "low": "78",
        "high": "90",
        "skycodeday": "11",
        "skytextday": "Rain",
        "date": "2022-09-28",
        "day": "Wednesday",
        "shortday": "Wed",
        "precip": "35"
      },
      {
        "low": "79",
        "high": "90",
        "skycodeday": "4",
        "skytextday": "T-Storms",
        "date": "2022-09-29",
        "day": "Thursday",
        "shortday": "Thu",
        "precip": "39"
      },
      {
        "low": "79",
        "high": "90",
        "skycodeday": "28",
        "skytextday": "Mostly Cloudy",
        "date": "2022-09-30",
        "day": "Friday",
        "shortday": "Fri",
        "precip": "29"
      },
      {
        "low": "79",
        "high": "91",
        "skycodeday": "28",
        "skytextday": "Mostly Cloudy",
        "date": "2022-10-01",
        "day": "Saturday",
        "shortday": "Sat",
        "precip": "33"
      }
    ]
  },
  {
    "location": {
      "name": "Davao Region, Philippines",
      "lat": "7.248",
      "long": "125.851",
      "timezone": "8",
      "alert": "",
      "degreetype": "F",
      "imagerelativeurl": "http://blob.weather.microsoft.com/static/weather4/en-us/"
    },
    "current": {
      "temperature": "83",
      "skycode": "9",
      "skytext": "Light Rain",
      "date": "2022-09-27",
      "observationtime": "19:46:15",
      "observationpoint": "Davao Region",
      "feelslike": "92",
      "humidity": "75",
      "winddisplay": "5 mph South",
      "day": "Tuesday",
      "shortday": "Tue",
      "windspeed": "5 mph",
      "imageUrl": "http://blob.weather.microsoft.com/static/weather4/en-us/law/9.gif"
    },
    "forecast": [
      {
        "low": "77",
        "high": "88",
        "skycodeday": "28",
        "skytextday": "Mostly Cloudy",
        "date": "2022-09-27",
        "day": "Tuesday",
        "shortday": "Tue",
        "precip": "14"
      },
      {
        low: "75",
        high: "87",
        skycodeday: "4",
        skytextday: "Heavy T-Storms",
        date: "2022-09-28",
        day: "Wednesday",
        shortday: "Wed",
        precip: "46"
      },
      {
        low: "76",
        high: "88",
        skycodeday: "4",
        skytextday: "T-Storms",
        date: "2022-09-29",
        day: "Thursday",
        shortday: "Thu",
        precip: "49"
      },
      {
        low: "76",
        high: "87",
        skycodeday: "4",
        skytextday: "Heavy T-Storms",
        date: "2022-09-30",
        day: "Friday",
        hortday: "Fri",
        precip: "52"
      },
      {
        low: "76",
        high: "88",
        skycodeday: "9",
        skytextday: "Light Rain",
        date: "2022-10-01",
        day: "Saturday",
        shortday: "Sat",
        precip: "36"
      }
    ]
  }
] };
 
  if(err) {
   console.log(err) 
   
  }
  else {
    
  console.log(JSON.stringify(result, null, 2)); 
  app.render('index.ejs', {data});
 //result.get('pages/index', weather)
 
  }
  
});

//app.listen(8080);
console.log('Server is listening on port 8080');

app.listen(3000);