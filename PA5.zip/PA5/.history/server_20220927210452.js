const express = require('express')
const app = express();
//app.set('views', './views');
app.set('view engine', 'ejs');
app.get('/', function (req, res) {
 

  //res.render('pages/index', data);
  res.render('index.ejs');
  res.render('other.ejs');
  
 app.use( express.static( "views" ) ); // not sure if tama

});
var weather = require('weather-js');
weather.find({search: 'Davao, PH', degreeType: 'F'}, function(err, result) {
  if(err) {
   console.log(err) 
  }
  else {
  console.log(JSON.stringify(result, null, 2)); 
  result.render(JSON.stringify(result)); 
 //result.get('pages/index', weather)
 
  }
});

//app.listen(8080);
console.log('Server is listening on port 8080');

app.listen(3000);