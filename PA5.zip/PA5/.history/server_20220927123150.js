const express = require('express')
const app = express();
//app.set('views', './views');
app.set('view engine', 'ejs');
app.get('/', function (req, res) {
 
  res.render('index.ejs');
  res.render('other.ejs');
});
app.use( express.static( "public" ) ); // not sure if tama
var weather = require('weather-js');
 
// Options:
// search:     location name or zipcode
// degreeType: F or C
 
weather.find({search: 'San Francisco, CA', degreeType: 'F'}, function(err, result) {
  if(err) console.log(err);

  console.log(JSON.stringify(result, null, 2));
});

app.listen(8080);
console.log('Server is listening on port 8080');

app.listen(3000);