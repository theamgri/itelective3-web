const express = require('express')
const app = express();

app.get('/', function (req, res) {
  res.send('Server Successful Loaded')
})

app.listen(3000);